/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connessionedb_fxml;

import connection.Connect;
import java.io.*;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author cesarano.carmine
 */
public class MySQL_FXML implements Initializable {
    @FXML
    private Label label;
    
    //Button
    @FXML
    private Button connect;
    @FXML
    private Button cancel;
    @FXML
    private Button test;
    
    @FXML
    private TextField hostname;
    @FXML
    private TextField port;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private TextArea output;
    @FXML
    private TextField connectionName;
    @FXML
    private TextField schema;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML
    public void clear(){
        hostname.clear();
        port.clear();
        username.clear();
        password.clear();
        output.clear();
        connectionName.clear();
    }
    
    @FXML
    private void initialize(ActionEvent event)throws FileNotFoundException, IOException, SQLException{
        String message=null;
        
        //Variabili contenenti il testo del TextField
        String host = hostname.getText();
        int porta = Integer.parseInt(port.getText());
        String user = username.getText();
        String pw = password.getText();
        String schemaDB = schema.getText();
        
        //Attributi per la connessione
        Connection con = null;
        Connect c = new Connect();
        
        //mi collego al database passando il metodo getConnection alla con------
        con = c.getConnection(host, porta, user, pw, schemaDB);
        System.out.println("Connesso: " + !con.isClosed());
        message = "Connesso: " + !con.isClosed();
        write(message);
        
        
        //Chiudo la connessione-------------------------------------------------
        con.close();
        System.out.println("Connesso: " + !con.isClosed());
        message =  "Connesso: " + !con.isClosed();
        write(message);
    }
    
    public void write(String m){
        output.appendText(m);
        output.appendText("");
    }
    
}
