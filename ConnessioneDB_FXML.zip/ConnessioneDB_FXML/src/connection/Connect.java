/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.Properties;

/**
 *
 * @author cesarano.carmine
 */
public class Connect {

    private Connection con = null;

    public Connection getConnection(String url, int port, String user, String password, String dbSchema) {

        //============================== 
        //Connessione senza PROPRIETIES
        //===============================
        if (con == null) {
            MysqlDataSource dataSource = new MysqlDataSource();
            dataSource.setServerName(url);
            dataSource.setPort(port);
            dataSource.setUser(user);
            dataSource.setPassword(password);

            if (dbSchema != null) {
                dataSource.setDatabaseName(dbSchema);
                try {
                    con = (Connection) dataSource.getConnection();
                } catch (SQLException e) {
                    
                    System.out.println("Errore");
                }
            }

        }
        return con;
    }

    public Connection getConnection() {

         //============================== 
        //Connessione con PROPRIETIES
        //===============================
        if (con == null) {
            //currentDir contiene la root di dove salvo i file
            Path currentDir = Paths.get("");
            System.out.println("" + currentDir.toAbsolutePath());

            FileReader reader = null;
            try {
                reader = new FileReader(currentDir.toAbsolutePath() + "/src/esempio/config/conf.dat");

                //creo un oggetto di tipo Properties
                Properties conf = new Properties();

                //carico la configurazione salvata sul file
                conf.load(reader);
                conf.setProperty("url", "cesarano.carmine.tave.osdb.it");
                conf.setProperty("port", "3306");
                conf.setProperty("user", "cesa");
                conf.setProperty("dbSchema", conf.getProperty("c101_cesa"));

            } catch (IOException e) {
                e.printStackTrace();
            }
            
            
        }
        return con;

    }
}
